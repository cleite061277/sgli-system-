#!/bin/bash

# ═══════════════════════════════════════════════════════════
# SCRIPT DE TESTE - PAINEL WHATSAPP
# ═══════════════════════════════════════════════════════════

echo "🔍 INICIANDO VALIDAÇÃO..."
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "manage.py" ]; then
    echo "❌ ERRO: Execute este script no diretório raiz do projeto"
    exit 1
fi

echo "✅ Diretório correto"

# Ativar ambiente virtual
if [ -d "venv" ]; then
    source venv/bin/activate
    echo "✅ Ambiente virtual ativado"
else
    echo "⚠️  AVISO: Ambiente virtual não encontrado"
fi

# Verificar arquivos necessários
echo ""
echo "📁 VERIFICANDO ARQUIVOS..."

FILES=(
    "core/views_whatsapp.py"
    "templates/core/painel_whatsapp.html"
)

all_ok=true
for file in "${FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "✅ $file"
    else
        echo "❌ $file - NÃO ENCONTRADO"
        all_ok=false
    fi
done

if [ "$all_ok" = false ]; then
    echo ""
    echo "❌ Alguns arquivos estão faltando. Execute a instalação primeiro."
    exit 1
fi

echo ""
echo "🔧 VERIFICANDO SINTAXE PYTHON..."

# Verificar sintaxe
python -m py_compile core/views_whatsapp.py 2>/dev/null
if [ $? -eq 0 ]; then
    echo "✅ views_whatsapp.py - Sintaxe OK"
else
    echo "❌ views_whatsapp.py - ERRO DE SINTAXE"
    python -m py_compile core/views_whatsapp.py
    exit 1
fi

echo ""
echo "🧪 TESTANDO IMPORTAÇÕES..."

# Testar imports
python << 'PYEOF'
import sys
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sgli_project.settings')

import django
django.setup()

try:
    from core.views_whatsapp import (
        painel_whatsapp,
        detalhe_comanda_whatsapp,
        api_mensagem_comanda,
        gerar_mensagem_whatsapp
    )
    print("✅ Todas as funções importadas corretamente")
    
    # Verificar se comandas existem
    from core.models import Comanda
    count = Comanda.objects.count()
    print(f"✅ {count} comandas encontradas no banco")
    
except Exception as e:
    print(f"❌ ERRO: {e}")
    sys.exit(1)
PYEOF

if [ $? -ne 0 ]; then
    echo "❌ Erro ao importar módulos"
    exit 1
fi

echo ""
echo "🌐 TESTANDO URLS..."

# Verificar se URLs estão configuradas
python << 'PYEOF'
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sgli_project.settings')

import django
django.setup()

from django.urls import resolve, reverse
from django.urls.exceptions import NoReverseMatch

try:
    url = reverse('painel_whatsapp')
    print(f"✅ URL 'painel_whatsapp' configurada: {url}")
except NoReverseMatch:
    print("❌ URL 'painel_whatsapp' NÃO ENCONTRADA")
    print("   Adicione as URLs em core/urls.py")
    import sys
    sys.exit(1)
PYEOF

if [ $? -ne 0 ]; then
    echo "⚠️  URLs não configuradas. Execute a integração primeiro."
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ VALIDAÇÃO CONCLUÍDA COM SUCESSO!"
echo "═══════════════════════════════════════════════════════════"
echo ""
echo "📋 PRÓXIMOS PASSOS:"
echo ""
echo "1. Execute o servidor local:"
echo "   python manage.py runserver"
echo ""
echo "2. Acesse no navegador:"
echo "   http://127.0.0.1:8000/admin/whatsapp/"
echo ""
echo "3. Faça o commit e push:"
echo "   git add ."
echo "   git commit -m 'feat: Adiciona Painel WhatsApp'"
echo "   git push origin main"
echo ""
echo "═══════════════════════════════════════════════════════════"
