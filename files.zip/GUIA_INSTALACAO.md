# 🚀 GUIA DE INTEGRAÇÃO - PAINEL WHATSAPP

## ✅ CHECKLIST DE INSTALAÇÃO

### PASSO 1: COPIAR ARQUIVOS (5 min)

```bash
# No diretório do projeto: ~/sgli_system/

# 1. Copiar view principal
cp views_whatsapp.py core/views_whatsapp.py

# 2. Criar diretório de templates se não existir
mkdir -p templates/core

# 3. Copiar template
cp painel_whatsapp.html templates/core/painel_whatsapp.html
```

---

### PASSO 2: INTEGRAR URLs (2 min)

Abra `core/urls.py` e adicione as importações e rotas:

```python
# NO INÍCIO DO ARQUIVO, adicione:
from core.views_whatsapp import (
    painel_whatsapp,
    detalhe_comanda_whatsapp,
    api_mensagem_comanda
)

# NO urlpatterns, adicione:
urlpatterns = [
    # ... suas rotas existentes ...
    
    # Painel WhatsApp
    path('admin/whatsapp/', painel_whatsapp, name='painel_whatsapp'),
    path('admin/whatsapp/comanda/<uuid:comanda_id>/', 
         detalhe_comanda_whatsapp, 
         name='detalhe_comanda_whatsapp'),
    path('admin/whatsapp/comanda/<uuid:comanda_id>/mensagem/', 
         api_mensagem_comanda, 
         name='api_mensagem_comanda'),
]
```

---

### PASSO 3: ADICIONAR LINK NO ADMIN (3 min)

Abra `templates/admin/base_site.html` (ou crie se não existir):

```html
{% extends "admin/base.html" %}

{% block nav-global %}
<div style="float: right; margin-right: 20px;">
    <a href="{% url 'painel_whatsapp' %}" 
       style="color: white; background: #25D366; padding: 8px 16px; 
              border-radius: 6px; text-decoration: none; font-weight: 600;">
        📱 Painel WhatsApp
    </a>
</div>
{{ block.super }}
{% endblock %}
```

---

### PASSO 4: TESTAR LOCALMENTE (5 min)

```bash
# Ativar ambiente virtual
cd ~/sgli_system
source venv/bin/activate

# Executar servidor
python manage.py runserver

# Acessar no navegador:
http://127.0.0.1:8000/admin/whatsapp/
```

**Validações:**
- [ ] Página carrega sem erros
- [ ] Estatísticas aparecem corretamente
- [ ] Lista de comandas exibe dados
- [ ] Botão "Copiar Mensagem" funciona
- [ ] Botão "Abrir WhatsApp" redireciona

---

### PASSO 5: COMMIT E PUSH (3 min)

```bash
cd ~/sgli_system

# Adicionar arquivos
git add core/views_whatsapp.py
git add templates/core/painel_whatsapp.html
git add core/urls.py

# Commit
git commit -m "feat: Adiciona Painel WhatsApp para notificações

- Implementa visualização de comandas mensais
- Botão copiar mensagem formatada
- Integração direta com WhatsApp Web
- Filtros por mês e status
- Dashboard com estatísticas"

# Push para Railway
git push origin main
```

---

## 📱 COMO USAR

### 1. ACESSAR O PAINEL

```
URL: https://romantic-liberation-production.up.railway.app/admin/whatsapp/
```

### 2. VISUALIZAR COMANDAS DO MÊS

- Dashboard mostra todas as comandas
- Filtrar por status (Pendente, Vencida, Paga)
- Selecionar mês de referência

### 3. ENVIAR VIA WHATSAPP

**OPÇÃO A - Copiar e Colar:**
1. Clique em "📋 Copiar Mensagem"
2. Abra WhatsApp Web manualmente
3. Cole a mensagem (Ctrl+V)
4. Envie

**OPÇÃO B - Abrir Direto:**
1. Clique em "💬 Abrir WhatsApp"
2. WhatsApp Web abre automaticamente
3. Mensagem já está copiada
4. Cole (Ctrl+V) e envie

---

## 🎨 FORMATO DA MENSAGEM

```
📋 *COMANDA DE ALUGUEL*

*Locatário:* João da Silva
*Imóvel:* Rua das Flores, 123
*Código:* APTO001

━━━━━━━━━━━━━━━━━━━
*REFERÊNCIA:* 10/2025
*Nº COMANDA:* 202510-0001
*VENCIMENTO:* 10/10/2025
━━━━━━━━━━━━━━━━━━━

*VALORES:*
• Aluguel: R$ 1.500,00
• Condomínio: R$ 300,00

*TOTAL: R$ 1.800,00*

⏰ Status: PENDENTE (5 dias para vencimento)

━━━━━━━━━━━━━━━━━━━
📞 Dúvidas? Entre em contato.
_Mensagem gerada automaticamente_
```

---

## 🔧 TROUBLESHOOTING

### Problema: Página não carrega

**Solução:**
```bash
# Verificar logs
python manage.py runserver
# Verificar se há erros de importação
```

### Problema: Botão "Copiar" não funciona

**Causa:** Navegador sem suporte a Clipboard API

**Solução:** Modal aparecerá automaticamente com texto para copiar manualmente

### Problema: Link do WhatsApp não abre

**Causa:** Formato do telefone incorreto

**Solução:** Telefone deve estar no formato: (41) 99999-9999 ou similar

---

## ✅ VALIDAÇÃO FINAL

Execute este checklist após deploy:

```bash
# Em produção (Railway)
curl https://romantic-liberation-production.up.railway.app/admin/whatsapp/

# Deve retornar HTML sem erro 500
```

**Checklist de Funcionalidade:**
- [ ] Página acessível em /admin/whatsapp/
- [ ] Dashboard carrega estatísticas
- [ ] Filtros funcionam
- [ ] Botão copiar funciona
- [ ] Link WhatsApp abre corretamente
- [ ] Mensagem formatada corretamente
- [ ] Valores em R$ aparecem corretos

---

## 🎯 PRÓXIMOS PASSOS (OPCIONAL)

1. **Email Automático** (30 min)
   - Configurar SMTP
   - Template de email
   - Comando de envio em lote

2. **Melhorias do Painel:**
   - Filtro por locatário específico
   - Envio em lote
   - Histórico de envios
   - Relatório de mensagens enviadas

---

## 📞 SUPORTE

Se encontrar problemas, verifique:
1. Logs do Railway
2. Console do navegador (F12)
3. Status do commit no GitHub

**Tempo total de instalação: ~15 minutos**
